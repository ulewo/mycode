package com.test.qqspace;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class NoteDao
{
	private NoteDao()
	{

	}

	private static NoteDao instance;

	/**
	 * 构�?实例
	 * 
	 * @return
	 */
	public synchronized static NoteDao getInstance()
	{

		if (instance == null)
		{
			instance = new NoteDao();
		}
		return instance;
	}

	public void adddQQ(String qq) throws Exception
	{

		ConnManage conManager = ConnManage.getInstance();
		Connection con = null;
		PreparedStatement ps = null;
		try
		{
			String sql = "insert into qqnumber (qq) values(?)";
			con = conManager.getConn();
			ps = con.prepareStatement(sql);
			ps.setString(1, qq);
			ps.executeUpdate();
		}
		catch (Exception e)
		{
			throw e;
		}
		finally
		{
			try
			{
				if (ps != null)
				{
					ps.close();
				}
				conManager.releaseConn(con);
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
	}
}
