package com.test.qqspace;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.htmlcleaner.HtmlCleaner;
import org.htmlcleaner.TagNode;

public class Fechqq
{
	private static DefaultHttpClient httpclient = new DefaultHttpClient();

	/**
	 * description: �����Ŀ��/����
	 * @param args
	 * @author luohl
	*/
	public static void main(String[] args)
	{

		String html = "";
		try
		{
			int num = 0;
			for (int i = 308108001; i <= 308109000; i++)
			{
				System.out.println("正在抓取的QQ号是:" + i);
				html = getQiushibaikeHTML("http://user.qzone.qq.com/" + i);
				HtmlCleaner htmlCleaner = new HtmlCleaner();
				TagNode allNode = htmlCleaner.clean(html);
				TagNode titleNode = allNode.findElementByName("title", true);
				String title = String.valueOf(titleNode.getText());
				if (title.contains("http://" + i + ".qzone.qq.com"))
				{
					try
					{
						NoteDao.getInstance().adddQQ(i + "");
					}
					catch (Exception e)
					{
						System.out.println(e);
						continue;
					}
					num++;
				}
				else
				{
					continue;
				}
			}
			System.out.println("一共获取了" + num + "个Q号");
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public static String getQiushibaikeHTML(String url) throws ClientProtocolException, IOException
	{

		HttpGet httpGet = new HttpGet(url);
		httpGet.addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
		httpGet.addHeader("Accept-Language", "zh-cn,zh;q=0.8,en-us;q=0.5,en;q=0.3");
		httpGet.addHeader("Connection", "Keep-Alive");
		httpGet.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 5.1; rv:15.0) Gecko/20100101 Firefox/15.0.1");
		HttpResponse response = httpclient.execute(httpGet);
		InputStream in = response.getEntity().getContent();
		String html = convertStreamToString(in, "utf-8");
		return html;
	}

	private static String convertStreamToString(InputStream is, String charset) throws UnsupportedEncodingException
	{

		BufferedReader reader = new BufferedReader(new InputStreamReader(is, charset));
		StringBuilder sb = new StringBuilder();
		String line = null;
		try
		{
			while ((line = reader.readLine()) != null)
			{
				sb.append(line + "\n");
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				is.close();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		return sb.toString();
	}
}
